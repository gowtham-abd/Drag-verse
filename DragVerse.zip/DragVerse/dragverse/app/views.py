from django.shortcuts import render ,redirect
from django.http import HttpResponse
from .models import Profile
from django.contrib.auth.hashers import make_password,check_password
# Create your views here.
def reg(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        if Profile.objects.filter(email=email).exists():
            return HttpResponse('Email already exists')
        if Profile.objects.filter(name=name).exists():
            return HttpResponse('Name already exists')
        
        hashed_password = make_password(password)
        
        user = Profile(name=name,email=email,password=hashed_password)
        user.save()
        return redirect('login')
        
    return render(request,'reg.html')

def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']

        user = Profile.objects.filter(email = email).first()
        if user:
            if check_password(password,user.password):
                return redirect('home')
        else:
            return HttpResponse('User not found')
        
    return render(request,'login.html')

def home(request):
    return render(request,'home.html')

def leaderboard(request):
    return render(request,'leaderboard.html')